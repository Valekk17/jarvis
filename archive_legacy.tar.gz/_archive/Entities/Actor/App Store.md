---
aliases:
- App Store
id: 3d361d22-1c7d-44d9-bd6d-8746bdc010d3
tags:
- Actor
type: Actor
---

# App Store

Apple's digital distribution platform for mobile apps.

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
