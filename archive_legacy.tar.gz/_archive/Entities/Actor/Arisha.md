---
aliases:
- Arisha
id: fcf602d5-6eb8-44cb-b792-15051df4239a
tags:
- Actor
type: Actor
---

# Arisha

Wife

## Relationships
### Outgoing
- **PROMISED** -> [[заказать дезики]]
- **PROMISED** -> [[страховка будет бесплатной]]
- **PROMISED** -> [[отправить напоминание Комбату]]
- **PROMISED** -> [[скачать себе одну фотографию]]
- **PROMISED** -> [[скачать и скинуть фотографии]]
- **PROMISED** -> [[подписать новости]]
- **PROMISED** -> [[просто покидать фотографии]]
- **PROMISED** -> [[отправить новости папе, Андрею и Кресечке]]
