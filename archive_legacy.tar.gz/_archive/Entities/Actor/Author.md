---
aliases:
- Author
id: 19493704-3e4a-4d2f-8017-8b892d4bc09a
tags:
- Actor
type: Actor
---

# Author

Writer of the source text discussing Context Graph

## Relationships
