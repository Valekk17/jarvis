---
aliases:
- Binance
id: 8bd99212-63e0-4e65-98e9-66ff5e1ab25a
tags:
- Actor
type: Actor
---

# Binance

Cryptocurrency exchange platform.

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
