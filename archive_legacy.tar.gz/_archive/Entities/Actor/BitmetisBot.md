---
aliases:
- '@BitmetisBot'
id: 4ed36611-80e9-4ed5-bb24-75d66768e79d
tags:
- Actor
type: Actor
---

# @BitmetisBot

Telegram bot for klapai.io

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
