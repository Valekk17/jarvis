---
aliases:
- '@BladeGamesBot'
id: dc04467c-aeb5-4580-bab5-d65260a5bc98
tags:
- Actor
type: Actor
---

# @BladeGamesBot

Telegram bot for focg.0g.ai

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
