---
aliases:
- Brave
id: 071d57bb-b8aa-42a1-ada3-3952505b351d
tags:
- Actor
type: Actor
---

# Brave

Service for web search (requires API Key)

## Relationships
