---
aliases:
- Buidlpad
id: cf1b3c44-6637-431f-8c9c-568bbc5e6e22
tags:
- Actor
type: Actor
---

# Buidlpad

Платформа

## Relationships
