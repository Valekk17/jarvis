---
aliases:
- Captain Gordeev
id: 80fc5179-78c8-4d66-a43e-169cd2a7e5db
tags:
- Actor
type: Actor
---

# Captain Gordeev

Captain who conducted an inspection

## Relationships
