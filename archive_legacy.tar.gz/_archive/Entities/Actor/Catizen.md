---
aliases:
- Catizen
id: 86bd7f0a-1b6b-4ba5-895c-8d653cae2cea
tags:
- Actor
type: Actor
---

# Catizen

Popular game with an associated token ($CATI).

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
