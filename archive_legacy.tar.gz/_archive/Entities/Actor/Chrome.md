---
aliases:
- Chrome
id: 6eed7a87-f956-46c0-a508-45f3557913af
tags:
- Actor
type: Actor
---

# Chrome

Web browser

## Relationships
