---
aliases:
- Claude 4.5 Opus
id: db0b8222-b4e2-4bf4-b6e8-bc9f6ea77e80
tags:
- Actor
type: Actor
---

# Claude 4.5 Opus

AI model

## Relationships
