---
aliases:
- Clawdbot
id: 329cfa1d-2ca8-4278-a4ad-86295fa8e47c
tags:
- Actor
type: Actor
---

# Clawdbot

Персональный ИИ-помощник

## Relationships
