---
aliases:
- Coinbase
id: ddf7426a-d821-4c30-b31a-1ebe534ba8dc
tags:
- Actor
type: Actor
---

# Coinbase

Cryptocurrency exchange platform.

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
