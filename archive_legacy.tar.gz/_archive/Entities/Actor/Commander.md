---
aliases:
- Commander
id: ddbc4e09-0564-4cad-ae01-e671c3f8627d
tags:
- Actor
type: Actor
---

# Commander

Leader whose decisions influence the platoon's situation

## Relationships
