---
aliases:
- Company Commander
id: e09ffc0e-1c72-4323-9b00-37555bca1b1a
tags:
- Actor
type: Actor
---

# Company Commander

An authority figure referred to as 'Ротный'.

## Relationships
