---
aliases:
- Context Graph
id: c33f46b3-96d2-40ed-a41e-a647c02e3901
tags:
- Actor
type: Actor
---

# Context Graph

Concept/feature for structured memory

## Relationships
