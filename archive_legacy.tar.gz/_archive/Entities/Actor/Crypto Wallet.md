---
aliases:
- Crypto Wallet
id: caa2a4e7-8258-4f47-bc6e-931a8b3314b3
tags:
- Actor
type: Actor
---

# Crypto Wallet

Platform for trading and managing cryptocurrencies, stocks, and funds; includes features like P2P Market and bonus programs.

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
