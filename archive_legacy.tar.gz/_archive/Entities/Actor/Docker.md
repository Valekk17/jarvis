---
aliases:
- Docker
id: 6425c74d-2d66-49e8-be0c-0b87c9ef08ee
tags:
- Actor
type: Actor
---

# Docker

Containerization platform for infrastructure

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
