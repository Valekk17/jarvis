---
aliases:
- Ethena
id: 59532438-194d-4c0b-8bd8-5842d2dc4164
tags:
- Actor
type: Actor
---

# Ethena

DeFi protocol for passive income in crypto.

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
