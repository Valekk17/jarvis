---
aliases:
- Ethereum
id: 2688b495-0eff-4b62-ac6b-d1134047386b
tags:
- Actor
type: Actor
---

# Ethereum

Cryptocurrency and blockchain network.

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
