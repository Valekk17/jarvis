---
aliases:
- Fitness House
id: 6c69fcd3-5d4a-4054-aa72-a2ce1fa3f80d
tags:
- Actor
type: Actor
---

# Fitness House

An organization mentioned in the context of an application.

## Relationships
