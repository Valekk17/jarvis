---
aliases:
- Flare
id: c5fe8e0a-2a5a-4f7d-9cbd-e170204951db
tags:
- Actor
type: Actor
---

# Flare

Blockchain network token (FLR) that helps dApps use external data.

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
