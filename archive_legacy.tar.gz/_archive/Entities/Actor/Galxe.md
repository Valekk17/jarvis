---
aliases:
- Galxe
id: 035ba66a-c915-4372-a129-6866852a8d35
tags:
- Actor
type: Actor
---

# Galxe

Платформа квестов

## Relationships
