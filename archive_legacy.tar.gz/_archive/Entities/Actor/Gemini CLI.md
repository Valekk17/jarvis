---
aliases:
- Gemini CLI
id: 25f9a626-f4e8-436a-a933-e5e4cc4c1ea7
tags:
- Actor
type: Actor
---

# Gemini CLI

Tool for entity extraction

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
