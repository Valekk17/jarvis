---
aliases:
- Gena
id: c19c01ee-9800-4408-b8d4-e3fdbfe08ba5
tags:
- Actor
type: Actor
---

# Gena

Person who left, related to an almost fire incident

## Relationships
