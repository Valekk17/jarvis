---
aliases:
- Git
id: 5ddf33c9-b91d-4731-842e-83bed647101d
tags:
- Actor
type: Actor
---

# Git

Version control system for raw data

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
