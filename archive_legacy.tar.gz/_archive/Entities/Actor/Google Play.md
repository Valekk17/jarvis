---
aliases:
- Google Play
id: 1776c488-6197-4648-b4ac-450a140a102f
tags:
- Actor
type: Actor
---

# Google Play

Google's digital distribution platform for mobile apps.

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
