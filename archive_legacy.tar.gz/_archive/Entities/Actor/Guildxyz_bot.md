---
aliases:
- '@Guildxyz_bot'
id: 669ca0d5-d1ac-4dde-b123-ee5f619c846c
tags:
- Actor
type: Actor
---

# @Guildxyz_bot

Telegram bot for guild-tg.com

## Relationships
