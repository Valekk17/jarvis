---
aliases:
- "Hamster (\u0442\u043E\u043A\u0435\u043D \u0438\u0433\u0440\u044B)"
id: 8af594b9-afa4-4fb2-a5cf-1a0327c15e5e
tags:
- Actor
type: Actor
---

# Hamster (токен игры)

Монета игры Hamster Kombat

## Relationships
