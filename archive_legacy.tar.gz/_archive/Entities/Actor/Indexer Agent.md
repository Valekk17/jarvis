---
aliases:
- Indexer Agent
id: 9369dd2b-6532-49ed-8476-725c5f0ab014
tags:
- Actor
type: Actor
---

# Indexer Agent

Component for entity extraction

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
