---
aliases:
- '@InferiumAI_bot'
id: de830f35-a7ac-4242-8110-d2336084b415
tags:
- Actor
type: Actor
---

# @InferiumAI_bot

Telegram bot for www.inferium.io

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
