---
aliases:
- Invesco QQQ
id: fa2142a7-0618-4305-bb47-e899ba9a919f
tags:
- Actor
type: Actor
---

# Invesco QQQ

Stock market index available as a tokenized fund.

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
