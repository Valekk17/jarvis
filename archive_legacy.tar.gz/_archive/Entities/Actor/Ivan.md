---
aliases:
- Ivan
id: 0e2a99ce-1662-4489-b5a2-0b8e0c518db1
tags:
- Actor
type: Actor
---

# Ivan

Specific person (example in queries for promises)

## Relationships
