---
aliases:
- J.A.R.V.I.S. casual
id: 88d73f7a-1e88-4393-b154-c2ed6ba08ccf
tags:
- Actor
type: Actor
---

# J.A.R.V.I.S. casual

Chat Partner

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
- [[Me]] -> **INTERACTED_WITH**
