---
aliases:
- Jarvis main
id: 6b30f2bb-0960-4872-a2ff-8a456af04086
tags:
- Actor
type: Actor
---

# Jarvis main

Main bot/agent in the OpenClaw system

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
