---
aliases:
- Jarvis
id: 4ac11bba-cbb5-47d1-9533-c78c19a1e6c0
tags:
- Actor
type: Actor
---

# Jarvis

Strategic AI Architect

## Relationships
### Outgoing
- **ASSISTS** -> [[Valekk_17]]
- **HAS_SKILL** -> [[Whisper]]
- **HAS_SKILL** -> [[Obsidian]]

### Incoming
- [[Valekk_17]] -> **CONTACT**
