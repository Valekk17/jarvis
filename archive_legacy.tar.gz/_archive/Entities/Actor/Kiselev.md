---
aliases:
- Kiselev
id: 44877506-e500-4e86-96ef-1b23007ef546
tags:
- Actor
type: Actor
---

# Kiselev

Person whose permission is sought to leave

## Relationships
