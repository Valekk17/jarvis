---
aliases:
- Krivoshein
id: cc4ed3dd-dbaf-48b5-a5ad-3fd1934ae312
tags:
- Actor
type: Actor
---

# Krivoshein

Person mentioned alongside Nekrasov

## Relationships
