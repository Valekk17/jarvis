---
aliases:
- MARIO
id: 73bc9f4c-a9fa-4e71-8856-7cc8a99fc9d8
tags:
- Actor
type: Actor
---

# MARIO

Субъект

## Relationships
