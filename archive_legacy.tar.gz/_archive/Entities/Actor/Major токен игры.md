---
aliases:
- "Major (\u0442\u043E\u043A\u0435\u043D \u0438\u0433\u0440\u044B)"
id: f745f942-a76b-4c60-a7e0-a32ecd54d576
tags:
- Actor
type: Actor
---

# Major (токен игры)

Токен популярной игры Major

## Relationships
