---
aliases:
- Major
id: 1595284d-9747-43fb-975d-32e132718c01
tags:
- Actor
type: Actor
---

# Major

Popular game with an associated token ($MAJOR).

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
