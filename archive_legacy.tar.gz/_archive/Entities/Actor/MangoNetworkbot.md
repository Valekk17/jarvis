---
aliases:
- '@MangoNetworkbot'
id: 490c4e99-a608-441f-b7ef-a43bd9eb5eb2
tags:
- Actor
type: Actor
---

# @MangoNetworkbot

Telegram bot for task.testnet.mangonetwork.io

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
