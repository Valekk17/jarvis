---
aliases:
- Monad
id: b660c0db-e6bb-4814-a5f8-342de38bda92
tags:
- Actor
type: Actor
---

# Monad

Blockchain network.

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
