---
aliases:
- MoneyGram
id: f6254fbb-1455-416f-bddf-36a8eb82a88d
tags:
- Actor
type: Actor
---

# MoneyGram

Global money transfer service.

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
