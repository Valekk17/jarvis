---
aliases:
- Nekrasov
id: a1d27a8e-c738-4820-8654-2df0ff0725a1
tags:
- Actor
type: Actor
---

# Nekrasov

Person described as doing nothing except for handling wood

## Relationships
