---
aliases:
- Netflix
id: fd1c6eb4-96d6-49be-aa22-1d0c6542ff3f
tags:
- Actor
type: Actor
---

# Netflix

Company whose shares are tokenized.

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
