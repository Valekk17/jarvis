---
aliases:
- NotebookLM
id: 75740e4f-d67f-4462-bf9a-05a5e340bec6
tags:
- Actor
type: Actor
---

# NotebookLM

Tool for deep research

## Relationships
