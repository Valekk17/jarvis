---
aliases:
- Nvidia
id: ae230204-24f5-43c5-b105-9843d38755b1
tags:
- Actor
type: Actor
---

# Nvidia

Company whose shares are tokenized.

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
