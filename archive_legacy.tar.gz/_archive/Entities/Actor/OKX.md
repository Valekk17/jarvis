---
aliases:
- OKX
id: f2b702dd-67ed-4108-a7f9-95371bc7f3b9
tags:
- Actor
type: Actor
---

# OKX

Cryptocurrency exchange platform.

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
