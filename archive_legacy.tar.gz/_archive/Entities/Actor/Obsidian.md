---
aliases:
- Obsidian
id: d60065f8-e22a-4005-b117-26933f62d856
tags:
- Actor
type: Actor
---

# Obsidian

Application for structured notes

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
