---
aliases:
- Oleg
id: 2053f361-610b-4930-81c4-891ec0ea13dc
tags:
- Actor
type: Actor
---

# Oleg

Person who needs to go to the pharmacy

## Relationships
