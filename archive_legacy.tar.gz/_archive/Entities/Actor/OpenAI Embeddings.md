---
aliases:
- OpenAI Embeddings
id: fad619f2-021f-44c6-81da-537074d8150d
tags:
- Actor
type: Actor
---

# OpenAI Embeddings

API for semantic search

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
