---
aliases:
- OpenLedger
id: ccbe6ccf-dedc-433a-a083-1b7d6606a212
tags:
- Actor
type: Actor
---

# OpenLedger

Проект/компания

## Relationships
