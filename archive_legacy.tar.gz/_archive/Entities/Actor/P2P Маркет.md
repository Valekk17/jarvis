---
aliases:
- "P2P \u041C\u0430\u0440\u043A\u0435\u0442"
id: 7997de45-bcbc-4f4c-8160-9738ee7d3c46
tags:
- Actor
type: Actor
---

# P2P Маркет

Площадка для торговли между пользователями в Кошельке

## Relationships
