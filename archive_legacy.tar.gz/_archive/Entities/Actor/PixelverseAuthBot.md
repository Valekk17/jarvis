---
aliases:
- '@PixelverseAuthBot'
id: 6abb2c2d-de95-4a31-b9de-fd77cb6887b3
tags:
- Actor
type: Actor
---

# @PixelverseAuthBot

Telegram bot for tg-connect.pxlvrs.io

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
