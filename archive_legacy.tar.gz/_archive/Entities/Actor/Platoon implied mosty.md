---
aliases:
- Platoon (implied 'mosty')
id: 8fe0fa3f-c429-4e95-9d99-9b2d529a0664
tags:
- Actor
type: Actor
---

# Platoon (implied 'mosty')

Group of people referred to as 'bridges' or a platoon, whose composition is 'not good'

## Relationships
