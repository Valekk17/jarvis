---
aliases:
- Pogolskiy
id: 398535ff-1ed1-4619-92a8-bcc8caeeb6ce
tags:
- Actor
type: Actor
---

# Pogolskiy

Person mentioned regarding checks and his status

## Relationships
