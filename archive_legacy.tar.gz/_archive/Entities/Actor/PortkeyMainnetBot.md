---
aliases:
- '@PortkeyMainnetBot'
id: 1b9c540c-c430-45d6-bcd2-da93cefb06d8
tags:
- Actor
type: Actor
---

# @PortkeyMainnetBot

Telegram bot for core.telegram.org

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
