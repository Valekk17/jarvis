---
aliases:
- PostgreSQL
id: 04737577-febf-4b4b-ba05-b6c1e351bedf
tags:
- Actor
type: Actor
---

# PostgreSQL

Database system for graph

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
