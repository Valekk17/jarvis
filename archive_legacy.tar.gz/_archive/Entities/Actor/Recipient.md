---
aliases:
- Recipient
id: bc866046-308c-408d-8f90-4d6155fedb97
tags:
- Actor
type: Actor
---

# Recipient

The person addressed directly ('ты')

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
