---
aliases:
- Sber
id: 70626af4-02fc-49c3-bd14-01e137bc5c77
tags:
- Actor
type: Actor
---

# Sber

Bank (related to Sber credit)

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
