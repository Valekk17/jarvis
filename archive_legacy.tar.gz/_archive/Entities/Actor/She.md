---
aliases:
- She
id: b10037bd-aa2b-4d1e-bfbb-6032371b380e
tags:
- Actor
type: Actor
---

# She

An unnamed female individual mentioned in the text.

## Relationships
