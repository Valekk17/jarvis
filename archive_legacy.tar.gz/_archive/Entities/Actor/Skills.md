---
aliases:
- Skills
id: a0b2be86-e264-4b6c-a0b5-4164174ee1fe
tags:
- Actor
type: Actor
---

# Skills

Entity type/group in graph

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
