---
aliases:
- Speaker
id: 65a7ef32-dc4e-47e1-8cf5-df6afcc1e781
tags:
- Actor
type: Actor
---

# Speaker

The person speaking/typing

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
