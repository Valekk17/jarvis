---
aliases:
- Spotify
id: f45098c2-dff4-4920-97bb-6a611112c6c3
tags:
- Actor
type: Actor
---

# Spotify

Музыкальный стриминговый сервис

## Relationships
