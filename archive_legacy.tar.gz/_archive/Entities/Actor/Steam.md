---
aliases:
- Steam
id: bbad14af-b3a4-4275-ba64-4d49e7f37244
tags:
- Actor
type: Actor
---

# Steam

Gaming platform

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
