---
aliases:
- Stellar
id: 345947fe-fed8-476c-8b5d-fac1af607734
tags:
- Actor
type: Actor
---

# Stellar

Blockchain network.

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
