---
aliases:
- Subordinate
id: bb05f78c-3cd7-413a-803d-82d893b67e7c
tags:
- Actor
type: Actor
---

# Subordinate

Неидентифицированный подчиненный, делающий доклады или запросы

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
