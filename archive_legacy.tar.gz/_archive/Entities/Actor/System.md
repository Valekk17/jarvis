---
aliases:
- System
id: d7fe134a-abdf-4adb-9e3d-385945d1b925
tags:
- Actor
type: Actor
---

# System

The AI itself, referred to as Я, OpenClaw, Агент, Система, jaarvvis_bot

## Relationships
