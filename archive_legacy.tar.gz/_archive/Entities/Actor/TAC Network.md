---
aliases:
- TAC Network
id: f870070f-bb56-4e47-8629-6bf0ce3b1197
tags:
- Actor
type: Actor
---

# TAC Network

Network that bridges Ethereum dApps to TON, with its own token (TAC).

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
