---
aliases:
- "TAC (\u0442\u043E\u043A\u0435\u043D \u0441\u0435\u0442\u0438 TAC)"
id: e1093c8c-e5a8-486a-b58a-59778f16201d
tags:
- Actor
type: Actor
---

# TAC (токен сети TAC)

Токен сети, переносящей децентрализованные приложения Ethereum в TON

## Relationships
