---
aliases:
- TBank
id: 70fe308e-a78b-45ed-8045-81c5224be7e8
tags:
- Actor
type: Actor
---

# TBank

Bank (Tinkoff Bank, from URL)

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
