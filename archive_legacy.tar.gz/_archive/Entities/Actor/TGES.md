---
aliases:
- TGES
id: fbe50917-1eac-47ad-9af7-9be4831fc004
tags:
- Actor
type: Actor
---

# TGES

Субъект

## Relationships
