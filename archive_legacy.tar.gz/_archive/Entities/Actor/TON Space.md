---
aliases:
- TON Space
id: 097e6007-8623-4482-ae96-432a4d5adcf7
tags:
- Actor
type: Actor
---

# TON Space

DeFi protocol within the TON ecosystem.

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
