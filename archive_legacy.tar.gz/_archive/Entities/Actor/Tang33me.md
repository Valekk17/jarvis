---
aliases:
- Tang33me
id: 57eb56e2-3629-4e4b-ad7c-e32732c73a7d
tags:
- Actor
type: Actor
---

# Tang33me

Device used for login attempt with Pyrogram

## Relationships
