---
aliases:
- Telegram Desktop
id: 24dccff0-6359-4fa8-9ec4-edc692954fd7
tags:
- Actor
type: Actor
---

# Telegram Desktop

Telegram application/device type

## Relationships
