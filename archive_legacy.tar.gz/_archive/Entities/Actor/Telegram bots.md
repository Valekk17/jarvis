---
aliases:
- Telegram bots
id: d7753106-1167-4e37-b434-1fe38d26a1e9
tags:
- Actor
type: Actor
---

# Telegram bots

Generic reference to bots configured for Telegram

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
- [[Me]] -> **INTERACTED_WITH**
