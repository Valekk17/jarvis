---
aliases:
- Tesla
id: cf9e69aa-45a2-4181-b198-6af01b0949a6
tags:
- Actor
type: Actor
---

# Tesla

Company whose shares are tokenized.

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
