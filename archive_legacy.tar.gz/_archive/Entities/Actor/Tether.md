---
aliases:
- Tether
id: 71273ab6-e7e4-4504-9059-acc7bd984783
tags:
- Actor
type: Actor
---

# Tether

Issuer of digital gold.

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
