---
aliases:
- The Group
id: 8b6c3c85-3be4-470c-8448-6d2da81effc2
tags:
- Actor
type: Actor
---

# The Group

Collective entity performing actions like sending surnames to chat.

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
