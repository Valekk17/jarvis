---
aliases:
- The Leader
id: ab196ca0-c3de-4e69-93b3-45534d359bac
tags:
- Actor
type: Actor
---

# The Leader

Individual who needs to be informed about people leaving formation.

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
