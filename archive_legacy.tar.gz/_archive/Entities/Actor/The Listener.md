---
aliases:
- The Listener
id: 5064cbb4-c8e0-4d6e-8f47-108fd711a6bb
tags:
- Actor
type: Actor
---

# The Listener

The person being addressed with questions and statements; did not collect a bonus.

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
