---
aliases:
- The Open Network (TON)
id: 19f47662-c661-4b55-8bf1-ad4f159a6d37
tags:
- Actor
type: Actor
---

# The Open Network (TON)

Блокчейн-сеть

## Relationships
