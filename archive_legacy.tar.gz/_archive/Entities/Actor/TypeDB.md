---
aliases:
- TypeDB
id: be9b2e01-8bf5-4982-95d5-689af5d9b55e
tags:
- Actor
type: Actor
---

# TypeDB

Database system for graph (alternative)

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
