---
aliases:
- Valek k
id: a9fb5c35-de20-4463-8497-d498f2b9868b
tags:
- Actor
type: Actor
---

# Valek k

Chat Partner

## Relationships

### Incoming
- [[Me]] -> **INTERACTED_WITH**
