---
aliases:
- Valek
id: 8da129cd-3cf1-473a-9cf8-ee9fd8a02fef
tags:
- Actor
type: Actor
---

# Valek

User; prefers high-signal, structured messages and full-width headers with status icons.

## Relationships
