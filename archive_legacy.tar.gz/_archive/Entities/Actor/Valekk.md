---
aliases:
- Valekk
id: 8bf0ba0d-ec9e-4e57-b183-2950f0a9e3b7
tags:
- Actor
type: Actor
---

# Valekk



## Relationships
### Outgoing
- **PROMISED** -> [[order deodorants]]
- **PROMISED** -> [[попросить Маму заехать в цветочный, выбрать букетик и перевести ей деньги]]
