---
aliases:
- Vercel
id: c8dcb3d3-7a79-45c9-a5d8-c1d7c7a0f536
tags:
- Actor
type: Actor
---

# Vercel

Компания, упоминаемая в URL

## Relationships
