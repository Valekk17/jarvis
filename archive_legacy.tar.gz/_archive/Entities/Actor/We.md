---
aliases:
- We
id: 3ecf7bfb-0340-4395-84ba-e27a698a272b
tags:
- Actor
type: Actor
---

# We

Group of individuals (implied speaker and associates)

## Relationships
