---
aliases:
- Whisper
id: 98b7d73e-bf01-4fbc-994b-4cc0988912a5
tags:
- Actor
type: Actor
---

# Whisper

Speech-to-text component

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
