---
aliases:
- X
id: 8fe70069-4ece-4ea3-8f3a-57bd9c841006
tags:
- Actor
type: Actor
---

# X

Платформа социальных медиа (бывший Twitter)

## Relationships
