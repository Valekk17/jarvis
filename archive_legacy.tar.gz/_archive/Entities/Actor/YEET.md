---
aliases:
- YEET
id: 8a0eb331-74ac-4e40-ab9a-3a3b41f90af6
tags:
- Actor
type: Actor
---

# YEET

Проект, перенесенный в гайды

## Relationships
