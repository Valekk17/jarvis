---
aliases:
- Yarmak
id: 83f2803a-072a-4f07-86af-320cfaf86b36
tags:
- Actor
type: Actor
---

# Yarmak

Person who will give money to Dimas

## Relationships
