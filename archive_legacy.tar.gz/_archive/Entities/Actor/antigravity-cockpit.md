---
aliases:
- antigravity-cockpit
id: 2cdfaa77-6988-4bd3-9970-ef730bf7b88a
tags:
- Actor
type: Actor
---

# antigravity-cockpit

Расширение для VS Code

## Relationships
