---
aliases:
- app.codatta.io
id: 5a855534-280a-4e81-80b2-321383ff4e1f
tags:
- Actor
type: Actor
---

# app.codatta.io

Website requesting Telegram account authorization

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
