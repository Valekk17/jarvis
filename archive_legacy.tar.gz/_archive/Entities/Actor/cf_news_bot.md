---
aliases:
- '@cf_news_bot'
id: a6d67f89-594d-41b6-b5cd-ef774423d437
tags:
- Actor
type: Actor
---

# @cf_news_bot

Telegram bot for crypto-family.com

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
