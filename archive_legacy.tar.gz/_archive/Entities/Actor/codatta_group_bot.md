---
aliases:
- '@codatta_group_bot'
id: dc365a3f-b84a-4e2a-b0d8-4c4311fff69a
tags:
- Actor
type: Actor
---

# @codatta_group_bot

Telegram bot for app.codatta.io

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
