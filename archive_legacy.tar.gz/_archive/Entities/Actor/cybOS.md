---
aliases:
- cybOS
id: 5aaabeb9-2754-4cc1-9495-629fbec474fd
tags:
- Actor
type: Actor
---

# cybOS

System

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
