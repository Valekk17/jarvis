---
aliases:
- '@cyberdrk/tg'
id: 0f4be204-1426-4025-aa58-f2f51307536e
tags:
- Actor
type: Actor
---

# @cyberdrk/tg

Telegram CLI binary

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
