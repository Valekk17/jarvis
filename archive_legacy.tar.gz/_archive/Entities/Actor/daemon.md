---
aliases:
- daemon
id: b23ad7c3-051f-412f-820a-fcdce8347a12
tags:
- Actor
type: Actor
---

# daemon

Role of OpenClaw

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
