---
aliases:
- focg.0g.ai
id: 64b6f59c-e2ea-4d9b-a478-ad20c7bf9e1a
tags:
- Actor
type: Actor
---

# focg.0g.ai

Website requesting Telegram account authorization

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
