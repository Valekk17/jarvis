---
aliases:
- fragment.com
id: 1660fdc6-6648-4193-8409-ad8ff8a713d7
tags:
- Actor
type: Actor
---

# fragment.com

Website requesting Telegram account authorization

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
