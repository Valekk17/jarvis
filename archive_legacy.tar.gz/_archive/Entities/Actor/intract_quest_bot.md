---
aliases:
- '@intract_quest_bot'
id: e9333640-acf7-47f6-b406-f9da3995ca1b
tags:
- Actor
type: Actor
---

# @intract_quest_bot

Telegram bot for www.intract.io

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
