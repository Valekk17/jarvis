---
aliases:
- klapai.io
id: 5b9ba68e-a9c9-41f3-ae4d-281f4eee2413
tags:
- Actor
type: Actor
---

# klapai.io

Website requesting Telegram account authorization

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
