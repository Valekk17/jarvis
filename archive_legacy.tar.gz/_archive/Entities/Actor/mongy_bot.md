---
aliases:
- '@mongy_bot'
id: bd25f501-6776-4e76-8c29-32b375948e6e
tags:
- Actor
type: Actor
---

# @mongy_bot

Telegram bot for bybit.mongysol.com

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
