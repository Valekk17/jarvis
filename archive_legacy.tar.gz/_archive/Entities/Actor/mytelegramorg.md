---
aliases:
- my.telegram.org
id: c6f57360-d67d-4b5d-a5f9-e3e3a0c2f568
tags:
- Actor
type: Actor
---

# my.telegram.org

Telegram authorization website

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
