---
aliases:
- n8n
id: 2c0b6747-3cbb-4a9e-bc7f-9ec2103a441e
tags:
- Actor
type: Actor
---

# n8n

Платформа автоматизации

## Relationships
