---
aliases:
- openclaw
id: 636a4d84-3c7d-4b66-8725-c75602cf15aa
tags:
- Actor
type: Actor
---

# openclaw

The software/system being used and configured

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
