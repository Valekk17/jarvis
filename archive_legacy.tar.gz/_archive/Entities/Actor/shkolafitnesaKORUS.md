---
aliases:
- shkolafitnesaKORUS
id: 78a28214-e12d-4dc4-b3df-02ec9881362a
tags:
- Actor
type: Actor
---

# shkolafitnesaKORUS

Organization/Company (from email address)

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
