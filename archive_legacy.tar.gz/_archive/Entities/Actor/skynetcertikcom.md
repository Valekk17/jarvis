---
aliases:
- skynet.certik.com
id: 897059e3-d7f5-4642-8e49-8cca64fa67f5
tags:
- Actor
type: Actor
---

# skynet.certik.com

Website requesting Telegram account authorization

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
