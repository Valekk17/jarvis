---
aliases:
- task.testnet.mangonetwork.io
id: adead135-714f-45cb-a567-f0c99c8d2794
tags:
- Actor
type: Actor
---

# task.testnet.mangonetwork.io

Website requesting Telegram account authorization

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
