---
aliases:
- tg-connect.pxlvrs.io
id: 02fce3ed-83b7-4133-8e4c-fee94ff0f99a
tags:
- Actor
type: Actor
---

# tg-connect.pxlvrs.io

Website requesting Telegram account authorization

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
