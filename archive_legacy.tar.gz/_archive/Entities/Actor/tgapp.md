---
aliases:
- tgapp
id: dc3700f0-240f-4d0a-99a6-488af4c24c75
tags:
- Actor
type: Actor
---

# tgapp

Device used for a login attempt

## Relationships

### Incoming
- [[Valekk_17]] -> **CONTACT**
