---
aliases:
- v1.ayakss.com
id: e7e9d9e8-5ef2-416a-ad1a-58444e233321
tags:
- Actor
type: Actor
---

# v1.ayakss.com

VPN service domain from the configuration link

## Relationships
