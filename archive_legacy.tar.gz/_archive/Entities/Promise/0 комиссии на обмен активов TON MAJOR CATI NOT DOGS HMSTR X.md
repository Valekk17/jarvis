---
aliases:
- "0% \u043A\u043E\u043C\u0438\u0441\u0441\u0438\u0438 \u043D\u0430 \u043E\u0431\u043C\
  \u0435\u043D \u0430\u043A\u0442\u0438\u0432\u043E\u0432 TON (MAJOR, CATI, NOT, DOGS,\
  \ HMSTR, X)"
id: 6624100d-ac0b-46a5-b242-c56616f53ae2
tags:
- Promise
type: Promise
---

# 0% комиссии на обмен активов TON (MAJOR, CATI, NOT, DOGS, HMSTR, X)

Status: Active

## Relationships
