---
aliases:
- A premium subscription can be given at a discount of up to 40% today.
id: 026a239a-8d70-4ba5-9a5c-69266a3f6a73
tags:
- Promise
type: Promise
---

# A premium subscription can be given at a discount of up to 40% today.

Status: Pending

## Relationships
