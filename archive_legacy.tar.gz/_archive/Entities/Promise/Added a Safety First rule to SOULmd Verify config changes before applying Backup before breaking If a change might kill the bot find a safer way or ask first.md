---
aliases:
- 'Added a ''Safety First'' rule to SOUL.md: ''Verify config changes before applying.
  Backup before breaking. If a change might kill the bot, find a safer way or ask
  first.'''
id: b38b5ca4-ed88-474c-b8fc-8cc6a1d46190
tags:
- Promise
type: Promise
---

# Added a 'Safety First' rule to SOUL.md: 'Verify config changes before applying. Backup before breaking. If a change might kill the bot, find a safer way or ask first.'

Status: Complete

## Relationships
