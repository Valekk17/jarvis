---
aliases:
- Added a new section 'Token Economy (Cost Efficiency)' to SOUL.md with specific guidelines
  (conciseness, edit vs send, context management, tool usage)
id: 51477734-2ca7-48a5-9dd0-76d3ac54b131
tags:
- Promise
type: Promise
---

# Added a new section 'Token Economy (Cost Efficiency)' to SOUL.md with specific guidelines (conciseness, edit vs send, context management, tool usage)

Status: Complete

## Relationships
