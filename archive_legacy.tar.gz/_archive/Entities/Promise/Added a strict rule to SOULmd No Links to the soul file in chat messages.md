---
aliases:
- 'Added a strict rule to SOUL.md: No Links to the soul file in chat messages'
id: 04246e77-3f99-4f86-951f-9df7ed149df6
tags:
- Promise
type: Promise
---

# Added a strict rule to SOUL.md: No Links to the soul file in chat messages

Status: Complete

## Relationships
