---
aliases:
- Any updates to the rules will apply to both bots instantly
id: e2391f31-a966-4c5e-8199-2b92ab2a5bf2
tags:
- Promise
type: Promise
---

# Any updates to the rules will apply to both bots instantly

Status: Pending

## Relationships
