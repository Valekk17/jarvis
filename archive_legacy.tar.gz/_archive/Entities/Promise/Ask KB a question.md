---
aliases:
- Ask KB a question
id: df874a40-cf7c-4502-9ed2-4526cf65e0e3
tags:
- Promise
type: Promise
---

# Ask KB a question

Status: Pending

## Relationships
