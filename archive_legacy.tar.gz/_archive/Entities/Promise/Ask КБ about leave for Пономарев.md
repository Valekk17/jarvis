---
aliases:
- "Ask \u041A\u0411 about leave for \u041F\u043E\u043D\u043E\u043C\u0430\u0440\u0435\
  \u0432"
id: 99abc472-6c3a-42a1-86f7-0735ff0db138
tags:
- Promise
type: Promise
---

# Ask КБ about leave for Пономарев

Status: Pending

## Relationships
