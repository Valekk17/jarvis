---
aliases:
- Authorized bots will gain the ability to write to Valek via Telegram.
id: 6b007bee-40e6-4ef8-b60f-915507ec336b
tags:
- Promise
type: Promise
---

# Authorized bots will gain the ability to write to Valek via Telegram.

Status: Fulfilled

## Relationships
