---
aliases:
- Authorized websites will know Valek's name, public link, and photo.
id: c696e27e-304d-458f-ac92-b7be80431061
tags:
- Promise
type: Promise
---

# Authorized websites will know Valek's name, public link, and photo.

Status: Fulfilled

## Relationships
