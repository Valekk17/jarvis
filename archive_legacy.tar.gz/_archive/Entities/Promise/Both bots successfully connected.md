---
aliases:
- Both bots successfully connected
id: 006ea1c4-b1b1-4d42-81fb-244bc5189695
tags:
- Promise
type: Promise
---

# Both bots successfully connected

Status: Complete

## Relationships
