---
aliases:
- Bots will try to report raw token usage instead of generic quota messages
id: 939c1d34-e064-48e6-b2e8-50ee4abf6196
tags:
- Promise
type: Promise
---

# Bots will try to report raw token usage instead of generic quota messages

Status: Pending

## Relationships
