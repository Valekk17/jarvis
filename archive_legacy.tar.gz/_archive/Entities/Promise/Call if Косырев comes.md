---
aliases:
- "Call if \u041A\u043E\u0441\u044B\u0440\u0435\u0432 comes"
id: a079969f-96fd-4c6b-a9d1-e37e34635225
tags:
- Promise
type: Promise
---

# Call if Косырев comes

Status: Pending

## Relationships
