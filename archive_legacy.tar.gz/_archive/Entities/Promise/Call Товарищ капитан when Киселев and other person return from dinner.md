---
aliases:
- "Call \u0422\u043E\u0432\u0430\u0440\u0438\u0449 \u043A\u0430\u043F\u0438\u0442\u0430\
  \u043D when \u041A\u0438\u0441\u0435\u043B\u0435\u0432 and other person return from\
  \ dinner"
id: b50d61cd-eedf-4b61-b443-deda15ba715c
tags:
- Promise
type: Promise
---

# Call Товарищ капитан when Киселев and other person return from dinner

Status: Pending

## Relationships
