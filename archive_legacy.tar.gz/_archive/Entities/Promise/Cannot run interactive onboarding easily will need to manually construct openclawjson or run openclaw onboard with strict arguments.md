---
aliases:
- Cannot run 'interactive' onboarding easily; will need to manually construct openclaw.json
  or run openclaw onboard with strict arguments
id: 8c10e951-74f8-4902-83d3-13269d52b2fa
tags:
- Promise
type: Promise
---

# Cannot run 'interactive' onboarding easily; will need to manually construct openclaw.json or run openclaw onboard with strict arguments

Status: Pending

## Relationships
