---
aliases:
- "Close KHO (\u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0435) storage"
id: d22c5d7b-814e-4dc2-a954-2cb4bf133f59
tags:
- Promise
type: Promise
---

# Close KHO (хранилище) storage

Status: Completed

## Relationships
