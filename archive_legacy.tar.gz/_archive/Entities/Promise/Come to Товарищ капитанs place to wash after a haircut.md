---
aliases:
- "Come to \u0422\u043E\u0432\u0430\u0440\u0438\u0449 \u043A\u0430\u043F\u0438\u0442\
  \u0430\u043D's place to wash after a haircut"
id: af3876e7-24f1-4fea-a519-8aed564b20f6
tags:
- Promise
type: Promise
---

# Come to Товарищ капитан's place to wash after a haircut

Status: Pending

## Relationships
