---
aliases:
- "Conduct evening roll call (\u0412\u041F)"
id: 7cb7bd78-abd6-405d-b3e8-2be909a67dcb
tags:
- Promise
type: Promise
---

# Conduct evening roll call (ВП)

Status: Completed

## Relationships
