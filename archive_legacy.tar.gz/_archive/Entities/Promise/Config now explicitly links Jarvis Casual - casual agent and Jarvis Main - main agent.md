---
aliases:
- Config now explicitly links Jarvis Casual -> casual agent and Jarvis (Main) -> main
  agent
id: a52e7ace-b05e-467f-9cbc-0ba2b6a47a53
tags:
- Promise
type: Promise
---

# Config now explicitly links Jarvis Casual -> casual agent and Jarvis (Main) -> main agent

Status: Complete

## Relationships
