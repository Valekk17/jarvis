---
aliases:
- Configured strict routing so Jarvis (Main) routes to Main Agent and Jarvis Casual
  routes to Casual Agent
id: e1c28e29-fca2-4378-a1a5-4e5122bce311
tags:
- Promise
type: Promise
---

# Configured strict routing so Jarvis (Main) routes to Main Agent and Jarvis Casual routes to Casual Agent

Status: Complete

## Relationships
