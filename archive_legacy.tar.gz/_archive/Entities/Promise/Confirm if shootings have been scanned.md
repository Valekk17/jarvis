---
aliases:
- Confirm if shootings have been scanned
id: 15584375-ba57-45e5-ba48-375b745eb3be
tags:
- Promise
type: Promise
---

# Confirm if shootings have been scanned

Status: Pending

## Relationships
