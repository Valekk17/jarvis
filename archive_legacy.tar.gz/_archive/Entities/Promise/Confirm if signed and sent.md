---
aliases:
- Confirm if signed and sent
id: 19395c43-0f60-4264-aa23-041bb19e5e9f
tags:
- Promise
type: Promise
---

# Confirm if signed and sent

Status: Pending

## Relationships
