---
aliases:
- Deleted the Telegram webhook completely to flush pending updates
id: bf00889b-e311-43b6-868a-aea26848a442
tags:
- Promise
type: Promise
---

# Deleted the Telegram webhook completely to flush pending updates

Status: Complete

## Relationships
