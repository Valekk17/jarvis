---
aliases:
- "Deliver a package to \u041F\u043E\u0434\u043F\u043E\u043B\u043A\u043E\u0432\u043D\
  \u0438\u043A \u041C\u0435\u043D\u044C\u0448\u0438\u043A\u043E\u0432"
id: 19fc054c-dd89-4a23-bcf2-51b6615ccc09
tags:
- Promise
type: Promise
---

# Deliver a package to Подполковник Меньшиков

Status: Pending

## Relationships
