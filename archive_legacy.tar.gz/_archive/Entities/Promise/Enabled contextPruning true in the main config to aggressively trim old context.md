---
aliases:
- 'Enabled contextPruning: true in the main config to aggressively trim old context'
id: d163a5ba-0c88-485d-9c18-1434c1721f7b
tags:
- Promise
type: Promise
---

# Enabled contextPruning: true in the main config to aggressively trim old context

Status: Complete

## Relationships
