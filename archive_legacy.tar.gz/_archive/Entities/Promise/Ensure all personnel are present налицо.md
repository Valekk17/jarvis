---
aliases:
- "Ensure all personnel are present (\u043D\u0430\u043B\u0438\u0446\u043E)"
id: 30c299d2-6317-4462-9553-5e7a508f7a8d
tags:
- Promise
type: Promise
---

# Ensure all personnel are present (налицо)

Status: Completed

## Relationships
