---
aliases:
- Ensure order in the platoon
id: 97495254-0fdf-4032-9db5-3d9e9c667dae
tags:
- Promise
type: Promise
---

# Ensure order in the platoon

Status: Pending

## Relationships
