---
aliases:
- "Inform \u0415\u0440\u044B\u0433\u0438\u043D about his need at shooting range"
id: b7ecc68a-f6b4-47ce-af4f-523accc91138
tags:
- Promise
type: Promise
---

# Inform Ерыгин about his need at shooting range

Status: Pending

## Relationships
