---
aliases:
- Jarvis (Main) and Jarvis Casual now share the exact same SOUL.md
id: 2c68c017-5b13-4c16-b9f1-82fa129b6dd5
tags:
- Promise
type: Promise
---

# Jarvis (Main) and Jarvis Casual now share the exact same SOUL.md

Status: Complete

## Relationships
