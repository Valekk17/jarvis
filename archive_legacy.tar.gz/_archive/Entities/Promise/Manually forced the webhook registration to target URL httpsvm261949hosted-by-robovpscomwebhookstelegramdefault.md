---
aliases:
- Manually forced the webhook registration to target URL https://vm261949.hosted-by-robovps.com/webhooks/telegram/default
id: 0df2402f-e2f6-4e27-8c72-c90dd8cc457b
tags:
- Promise
type: Promise
---

# Manually forced the webhook registration to target URL https://vm261949.hosted-by-robovps.com/webhooks/telegram/default

Status: Complete

## Relationships
