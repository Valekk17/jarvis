---
aliases:
- "Meet the \u041F\u043E\u043B\u043A\u043E\u0432\u043D\u0438\u043A personally"
id: 77a5f169-f217-411a-9a3b-608a911c7cdd
tags:
- Promise
type: Promise
---

# Meet the Полковник personally

Status: Pending

## Relationships
