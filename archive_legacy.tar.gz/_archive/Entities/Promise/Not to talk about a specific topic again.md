---
aliases:
- Not to talk about a specific topic again
id: f1338059-174b-46b5-8fd8-d96d0d3e915f
tags:
- Promise
type: Promise
---

# Not to talk about a specific topic again

Status: Pending

## Relationships
