---
aliases:
- Pay administrative fine
id: 3a7c7533-8aaa-4baa-93ba-1aa249de106d
tags:
- Promise
type: Promise
---

# Pay administrative fine

Status: Pending

## Relationships
