---
aliases:
- Print a tag for a box for the lighthouse
id: b58909b7-da6b-487b-8561-dcc707322c85
tags:
- Promise
type: Promise
---

# Print a tag for a box for the lighthouse

Status: Pending

## Relationships
