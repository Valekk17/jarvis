---
aliases:
- Provide report on shootings
id: 52c3264b-162f-4839-bbf1-4679a1d82f74
tags:
- Promise
type: Promise
---

# Provide report on shootings

Status: Pending

## Relationships
