---
aliases:
- "Put a chocolate bar on \u0422\u043E\u0432\u0430\u0440\u0438\u0449 \u043A\u0430\u043F\
  \u0438\u0442\u0430\u043D's table"
id: 741444cb-d2f0-4e5b-962c-5417d7bafeb7
tags:
- Promise
type: Promise
---

# Put a chocolate bar on Товарищ капитан's table

Status: Completed

## Relationships
