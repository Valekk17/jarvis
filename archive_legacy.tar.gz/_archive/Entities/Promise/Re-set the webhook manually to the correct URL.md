---
aliases:
- Re-set the webhook manually to the correct URL
id: f2fcc421-af24-4fe6-88b3-d9d32e2c1338
tags:
- Promise
type: Promise
---

# Re-set the webhook manually to the correct URL

Status: Complete

## Relationships
