---
aliases:
- Read message with corrected lists
id: 8960c8c7-c015-40a1-b20a-934263e61861
tags:
- Promise
type: Promise
---

# Read message with corrected lists

Status: Fulfilled

## Relationships
