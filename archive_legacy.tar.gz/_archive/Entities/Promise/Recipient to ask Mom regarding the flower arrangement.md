---
aliases:
- Recipient to ask Mom (regarding the flower arrangement).
id: d5068f46-2479-416c-aff8-fb2970760734
tags:
- Promise
type: Promise
---

# Recipient to ask Mom (regarding the flower arrangement).

Status: Pending

## Relationships
