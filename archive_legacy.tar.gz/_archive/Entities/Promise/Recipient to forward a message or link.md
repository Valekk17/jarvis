---
aliases:
- Recipient to forward a message or link.
id: 5414d350-96b7-493a-a59e-f156a7288fde
tags:
- Promise
type: Promise
---

# Recipient to forward a message or link.

Status: Pending

## Relationships
