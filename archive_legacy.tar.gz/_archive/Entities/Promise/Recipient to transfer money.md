---
aliases:
- Recipient to transfer money.
id: d787d7ff-7568-4aa5-991c-c71602697765
tags:
- Promise
type: Promise
---

# Recipient to transfer money.

Status: Pending

## Relationships
