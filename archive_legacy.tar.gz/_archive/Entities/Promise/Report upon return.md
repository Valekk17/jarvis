---
aliases:
- Report upon return
id: aa793714-2c2f-4cfa-80f9-04416b5aa3e6
tags:
- Promise
type: Promise
---

# Report upon return

Status: Pending

## Relationships
