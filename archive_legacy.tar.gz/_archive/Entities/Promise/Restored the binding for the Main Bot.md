---
aliases:
- Restored the binding for the Main Bot
id: 7a330d81-4466-4fc7-b11b-f42b32d1971d
tags:
- Promise
type: Promise
---

# Restored the binding for the Main Bot

Status: Complete

## Relationships
