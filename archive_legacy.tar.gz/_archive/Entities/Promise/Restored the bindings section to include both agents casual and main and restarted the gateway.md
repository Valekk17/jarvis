---
aliases:
- Restored the bindings section to include both agents (casual and main) and restarted
  the gateway
id: ecc1a5cb-74ae-4e6d-adc4-5d9613ab698c
tags:
- Promise
type: Promise
---

# Restored the bindings section to include both agents (casual and main) and restarted the gateway

Status: Complete

## Relationships
