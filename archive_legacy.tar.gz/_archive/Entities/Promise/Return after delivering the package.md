---
aliases:
- Return after delivering the package
id: 250651d8-1e5d-4b48-94d5-567ab5d85f1a
tags:
- Promise
type: Promise
---

# Return after delivering the package

Status: Pending

## Relationships
