---
aliases:
- Send extracts from order for January shootings
id: 9db02e7c-7670-4255-88b0-2d95c8d81fcf
tags:
- Promise
type: Promise
---

# Send extracts from order for January shootings

Status: Pending

## Relationships
