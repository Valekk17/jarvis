---
aliases:
- "Send \u0413\u0430\u0441\u0430\u043D\u043E\u0432's number"
id: 69187ac9-3241-4f5b-9ecb-54cd5c466b0b
tags:
- Promise
type: Promise
---

# Send Гасанов's number

Status: Pending

## Relationships
