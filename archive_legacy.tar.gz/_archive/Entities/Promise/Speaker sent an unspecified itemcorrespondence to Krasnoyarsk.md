---
aliases:
- Speaker sent an unspecified item/correspondence to Krasnoyarsk.
id: abde9432-ce01-4c34-b76c-14e9857e1480
tags:
- Promise
type: Promise
---

# Speaker sent an unspecified item/correspondence to Krasnoyarsk.

Status: Completed

## Relationships
