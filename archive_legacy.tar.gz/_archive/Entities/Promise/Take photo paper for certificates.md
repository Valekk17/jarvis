---
aliases:
- Take photo paper for certificates
id: 035b6e09-11e7-43a8-b688-404200d044df
tags:
- Promise
type: Promise
---

# Take photo paper for certificates

Status: Pending

## Relationships
