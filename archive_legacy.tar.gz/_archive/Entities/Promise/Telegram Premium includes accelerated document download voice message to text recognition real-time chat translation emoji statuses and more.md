---
aliases:
- Telegram Premium includes accelerated document download, voice message to text recognition,
  real-time chat translation, emoji statuses, and more.
id: 6e070ef9-df81-4dbc-8789-afd5a7ea1a8e
tags:
- Promise
type: Promise
---

# Telegram Premium includes accelerated document download, voice message to text recognition, real-time chat translation, emoji statuses, and more.

Status: Pending

## Relationships
