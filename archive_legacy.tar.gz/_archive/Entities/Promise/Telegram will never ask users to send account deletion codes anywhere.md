---
aliases:
- Telegram will never ask users to send account deletion codes anywhere.
id: 39ebfe70-865f-4c2b-b278-7101c42c7ba7
tags:
- Promise
type: Promise
---

# Telegram will never ask users to send account deletion codes anywhere.

Status: Fulfilled

## Relationships
