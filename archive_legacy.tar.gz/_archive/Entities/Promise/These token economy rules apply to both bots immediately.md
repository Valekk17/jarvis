---
aliases:
- These token economy rules apply to both bots immediately
id: 8778e159-cb64-4ac4-a701-5585d1003a62
tags:
- Promise
type: Promise
---

# These token economy rules apply to both bots immediately

Status: Pending

## Relationships
