---
aliases:
- To ask him later (about VPN details)
id: 5af64110-f181-4d5e-893c-b6a238a2379a
tags:
- Promise
type: Promise
---

# To ask him later (about VPN details)

Status: Pending

## Relationships
