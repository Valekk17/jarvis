---
aliases:
- To check something every 10 minutes
id: 38b29a71-d076-4e46-af18-abe86ba46dd6
tags:
- Promise
type: Promise
---

# To check something every 10 minutes

Status: Pending

## Relationships
