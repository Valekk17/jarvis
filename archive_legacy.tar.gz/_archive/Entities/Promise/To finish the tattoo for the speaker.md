---
aliases:
- To finish the tattoo for the speaker
id: f4193fa3-e489-4777-9c61-72228182d2bf
tags:
- Promise
type: Promise
---

# To finish the tattoo for the speaker

Status: Pending

## Relationships
