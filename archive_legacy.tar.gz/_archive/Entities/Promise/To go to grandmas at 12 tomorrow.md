---
aliases:
- To go to grandma's at 12 tomorrow
id: d6450ebc-c3ba-4da3-badf-eedb286fd366
tags:
- Promise
type: Promise
---

# To go to grandma's at 12 tomorrow

Status: Pending

## Relationships
