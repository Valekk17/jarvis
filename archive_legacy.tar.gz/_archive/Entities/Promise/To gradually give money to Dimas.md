---
aliases:
- To gradually give money to Dimas
id: 464cca1b-083a-493f-8d96-b85b96132125
tags:
- Promise
type: Promise
---

# To gradually give money to Dimas

Status: Pending

## Relationships
