---
aliases:
- "To send a code (to a person) when '\u0442\u044B' arrives"
id: aa98af17-79cc-47af-a706-0e2b421fee1b
tags:
- Promise
type: Promise
---

# To send a code (to a person) when 'ты' arrives

Status: Pending

## Relationships
