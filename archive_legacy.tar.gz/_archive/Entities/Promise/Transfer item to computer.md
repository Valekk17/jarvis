---
aliases:
- Transfer item to computer
id: 3a8520a7-639c-4069-9afc-31d170341e4d
tags:
- Promise
type: Promise
---

# Transfer item to computer

Status: Pending

## Relationships
