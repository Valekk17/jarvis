---
aliases:
- "Updated SOUL.md for Jarvis (Main): will send one message with plan, edit in real-time,\
  \ use symbols (\u25CC, \u27F3, \u2713), and use thematic phrases instead of percentages"
id: 8bb986f1-4527-43aa-89bb-d89be9faa43b
tags:
- Promise
type: Promise
---

# Updated SOUL.md for Jarvis (Main): will send one message with plan, edit in real-time, use symbols (◌, ⟳, ✓), and use thematic phrases instead of percentages

Status: Complete

## Relationships
