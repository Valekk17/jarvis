---
aliases:
- Visit headquarters upon return
id: 67f834e0-3e99-4a21-ab15-0ad1c6d98793
tags:
- Promise
type: Promise
---

# Visit headquarters upon return

Status: Pending

## Relationships
