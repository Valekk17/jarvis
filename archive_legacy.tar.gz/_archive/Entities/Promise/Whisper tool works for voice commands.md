---
aliases:
- Whisper tool works for voice commands
id: 837768d5-90e0-4fd5-87e4-09c41b43feb8
tags:
- Promise
type: Promise
---

# Whisper tool works for voice commands

Status: Complete

## Relationships
