---
aliases:
- Will delete ~/.openclaw (except the backup)
id: a501d0cb-3342-40bd-991d-8e8da4810ad0
tags:
- Promise
type: Promise
---

# Will delete ~/.openclaw (except the backup)

Status: Pending

## Relationships
