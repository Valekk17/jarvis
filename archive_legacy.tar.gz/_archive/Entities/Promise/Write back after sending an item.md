---
aliases:
- Write back after sending an item
id: 09a51358-4a5c-4e8e-98fa-09be9fba87ee
tags:
- Promise
type: Promise
---

# Write back after sending an item

Status: Pending

## Relationships
