---
aliases:
- order deodorants
id: 5c565883-c9bb-427c-a76d-ac36ee2b0d92
tags:
- Promise
type: Promise
---

# order deodorants

Status: pending

## Relationships

### Incoming
- [[Valekk]] -> **PROMISED**
