---
aliases:
- "\u0411\u0435\u0441\u043F\u043B\u0430\u0442\u043D\u043E \u043E\u0442\u043F\u0440\
  \u0430\u0432\u043B\u044F\u0442\u044C \u0442\u043E\u043A\u0435\u043D\u044B CATI \u0441\
  \u0432\u043E\u0438\u043C \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u0430\u043C\
  \ \u0432 Telegram"
id: d22108bd-2233-43de-8fec-18985f16bb4e
tags:
- Promise
type: Promise
---

# Бесплатно отправлять токены CATI своим контактам в Telegram

Status: Fulfilled

## Relationships
