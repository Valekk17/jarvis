---
aliases:
- "\u0412\u0430\u0448\u0438 TON \u0432\u0441\u0435\u0433\u0434\u0430 \u043E\u0441\u0442\
  \u0430\u044E\u0442\u0441\u044F \u043D\u0430 \u0432\u0430\u0448\u0435\u043C \u0441\
  \u0447\u0451\u0442\u0435 \u0438 \u043F\u043E\u0434 \u0432\u0430\u0448\u0438\u043C\
  \ \u043A\u043E\u043D\u0442\u0440\u043E\u043B\u0435\u043C"
id: 0ef373f8-a7b2-4e6c-b26f-1a1d06c49edd
tags:
- Promise
type: Promise
---

# Ваши TON всегда остаются на вашем счёте и под вашим контролем

Status: Fulfilled

## Relationships
