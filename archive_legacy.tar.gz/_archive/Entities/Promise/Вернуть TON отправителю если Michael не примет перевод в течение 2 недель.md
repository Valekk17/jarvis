---
aliases:
- "\u0412\u0435\u0440\u043D\u0443\u0442\u044C TON \u043E\u0442\u043F\u0440\u0430\u0432\
  \u0438\u0442\u0435\u043B\u044E, \u0435\u0441\u043B\u0438 Michael \u043D\u0435 \u043F\
  \u0440\u0438\u043C\u0435\u0442 \u043F\u0435\u0440\u0435\u0432\u043E\u0434 \u0432\
  \ \u0442\u0435\u0447\u0435\u043D\u0438\u0435 2 \u043D\u0435\u0434\u0435\u043B\u044C"
id: c20468d7-fb2e-419f-853d-898b0bbb7f85
tags:
- Promise
type: Promise
---

# Вернуть TON отправителю, если Michael не примет перевод в течение 2 недель

Status: Pending

## Relationships
