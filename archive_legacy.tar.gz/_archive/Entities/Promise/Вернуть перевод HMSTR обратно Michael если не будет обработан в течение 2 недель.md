---
aliases:
- "\u0412\u0435\u0440\u043D\u0443\u0442\u044C \u043F\u0435\u0440\u0435\u0432\u043E\
  \u0434 HMSTR \u043E\u0431\u0440\u0430\u0442\u043D\u043E Michael, \u0435\u0441\u043B\
  \u0438 \u043D\u0435 \u0431\u0443\u0434\u0435\u0442 \u043E\u0431\u0440\u0430\u0431\
  \u043E\u0442\u0430\u043D \u0432 \u0442\u0435\u0447\u0435\u043D\u0438\u0435 2 \u043D\
  \u0435\u0434\u0435\u043B\u044C"
id: d7394f02-407a-40cc-b5e7-afe9f3fd8a99
tags:
- Promise
type: Promise
---

# Вернуть перевод HMSTR обратно Michael, если не будет обработан в течение 2 недель

Status: Pending

## Relationships
