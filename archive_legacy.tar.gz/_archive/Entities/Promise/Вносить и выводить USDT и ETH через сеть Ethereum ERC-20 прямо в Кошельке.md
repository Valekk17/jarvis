---
aliases:
- "\u0412\u043D\u043E\u0441\u0438\u0442\u044C \u0438 \u0432\u044B\u0432\u043E\u0434\
  \u0438\u0442\u044C USDT \u0438 ETH \u0447\u0435\u0440\u0435\u0437 \u0441\u0435\u0442\
  \u044C Ethereum (ERC-20) \u043F\u0440\u044F\u043C\u043E \u0432 \u041A\u043E\u0448\
  \u0435\u043B\u044C\u043A\u0435"
id: f63660a7-9b02-4ff6-9089-caeddc99c1b5
tags:
- Promise
type: Promise
---

# Вносить и выводить USDT и ETH через сеть Ethereum (ERC-20) прямо в Кошельке

Status: Fulfilled

## Relationships
