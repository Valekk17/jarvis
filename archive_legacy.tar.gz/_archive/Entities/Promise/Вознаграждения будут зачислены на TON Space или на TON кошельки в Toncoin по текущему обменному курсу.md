---
aliases:
- "\u0412\u043E\u0437\u043D\u0430\u0433\u0440\u0430\u0436\u0434\u0435\u043D\u0438\u044F\
  \ \u0431\u0443\u0434\u0443\u0442 \u0437\u0430\u0447\u0438\u0441\u043B\u0435\u043D\
  \u044B \u043D\u0430 TON Space \u0438\u043B\u0438 \u043D\u0430 TON \u043A\u043E\u0448\
  \u0435\u043B\u044C\u043A\u0438 \u0432 Toncoin \u043F\u043E \u0442\u0435\u043A\u0443\
  \u0449\u0435\u043C\u0443 \u043E\u0431\u043C\u0435\u043D\u043D\u043E\u043C\u0443\
  \ \u043A\u0443\u0440\u0441\u0443"
id: bb15f6a5-a0e0-4260-8159-c14b98f33757
tags:
- Promise
type: Promise
---

# Вознаграждения будут зачислены на TON Space или на TON кошельки в Toncoin по текущему обменному курсу

Status: Fulfilled

## Relationships
