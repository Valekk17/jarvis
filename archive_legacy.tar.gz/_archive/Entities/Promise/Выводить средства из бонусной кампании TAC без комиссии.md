---
aliases:
- "\u0412\u044B\u0432\u043E\u0434\u0438\u0442\u044C \u0441\u0440\u0435\u0434\u0441\
  \u0442\u0432\u0430 \u0438\u0437 \u0431\u043E\u043D\u0443\u0441\u043D\u043E\u0439\
  \ \u043A\u0430\u043C\u043F\u0430\u043D\u0438\u0438 TAC \u0431\u0435\u0437 \u043A\
  \u043E\u043C\u0438\u0441\u0441\u0438\u0438"
id: 1c9a4ed2-da25-44cd-a305-301e55d9aeb6
tags:
- Promise
type: Promise
---

# Выводить средства из бонусной кампании TAC без комиссии

Status: Fulfilled

## Relationships
