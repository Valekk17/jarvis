---
aliases:
- "\u0413\u043E\u0440\u0434\u0435\u0435\u0432 will sign"
id: 63a6a13e-0533-462d-a140-b32dae2e8fcd
tags:
- Promise
type: Promise
---

# Гордеев will sign

Status: Pending

## Relationships
