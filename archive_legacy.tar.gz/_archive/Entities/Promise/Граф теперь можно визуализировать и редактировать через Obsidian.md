---
aliases:
- "\u0413\u0440\u0430\u0444 \u0442\u0435\u043F\u0435\u0440\u044C \u043C\u043E\u0436\
  \u043D\u043E \u0432\u0438\u0437\u0443\u0430\u043B\u0438\u0437\u0438\u0440\u043E\u0432\
  \u0430\u0442\u044C \u0438 \u0440\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\
  \u0432\u0430\u0442\u044C \u0447\u0435\u0440\u0435\u0437 Obsidian"
id: eb98b070-8386-4043-aca6-76203fba57ad
tags:
- Promise
type: Promise
---

# Граф теперь можно визуализировать и редактировать через Obsidian

Status: Pending

## Relationships
