---
aliases:
- "\u0414\u0435\u0434\u043B\u0430\u0439\u043D \u043A\u0432\u0435\u0441\u0442\u0430\
  \ Galxe: We're Live on Kaito!"
id: e1ac3f8a-7432-4174-9077-38367f3c8946
tags:
- Promise
type: Promise
---

# Дедлайн квеста Galxe: We're Live on Kaito!

Status: Pending

## Relationships
