---
aliases:
- "\u0417\u0430\u043A\u043E\u043D\u0447\u0438\u043B \u0438\u043C\u043F\u043E\u0440\
  \u0442 \u0438\u0441\u0442\u043E\u0440\u0438\u0438 Telegram. \u0421\u043A\u0440\u0438\
  \u043F\u0442 \u043F\u0440\u043E\u0448\u0435\u043B \u043F\u043E \u0432\u0441\u0435\
  \u043C \u0447\u0430\u0442\u0430\u043C. \u0413\u0440\u0430\u0444 \u043E\u0431\u043D\
  \u043E\u0432\u043B\u0435\u043D."
id: 5ca16b40-bea0-4c69-b23d-a006d2fe0426
tags:
- Promise
type: Promise
---

# Закончил импорт истории Telegram. Скрипт прошел по всем чатам. Граф обновлен.

Status: Fulfilled

## Relationships
