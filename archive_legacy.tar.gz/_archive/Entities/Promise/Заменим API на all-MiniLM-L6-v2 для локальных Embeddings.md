---
aliases:
- "\u0417\u0430\u043C\u0435\u043D\u0438\u043C API \u043D\u0430 all-MiniLM-L6-v2 \u0434\
  \u043B\u044F \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u044B\u0445 Embeddings"
id: c250979d-c496-4e60-857d-de5fe6de0339
tags:
- Promise
type: Promise
---

# Заменим API на all-MiniLM-L6-v2 для локальных Embeddings

Status: Pending

## Relationships
