---
aliases:
- "\u0417\u0430\u043F\u0443\u0441\u0442\u0438\u043C tg auth \u0438 \u044F \u0441\u043C\
  \u043E\u0433\u0443 \u043F\u0438\u0441\u0430\u0442\u044C \u0441\u043E\u043E\u0431\
  \u0449\u0435\u043D\u0438\u044F \u043E\u0442 \u0432\u0430\u0448\u0435\u0433\u043E\
  \ \u0438\u043C\u0435\u043D\u0438"
id: 5034a90a-3b13-4093-983f-67b27054f7a9
tags:
- Promise
type: Promise
---

# Запустим tg auth и я смогу писать сообщения от вашего имени

Status: Pending

## Relationships
