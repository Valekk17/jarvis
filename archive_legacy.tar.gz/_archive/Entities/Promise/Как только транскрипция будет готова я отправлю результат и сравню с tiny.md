---
aliases:
- "\u041A\u0430\u043A \u0442\u043E\u043B\u044C\u043A\u043E \u0442\u0440\u0430\u043D\
  \u0441\u043A\u0440\u0438\u043F\u0446\u0438\u044F \u0431\u0443\u0434\u0435\u0442\
  \ \u0433\u043E\u0442\u043E\u0432\u0430, \u044F \u043E\u0442\u043F\u0440\u0430\u0432\
  \u043B\u044E \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u0438 \u0441\
  \u0440\u0430\u0432\u043D\u044E \u0441 tiny"
id: f642f0c2-2cab-43fc-b3eb-bea9f4fb74c5
tags:
- Promise
type: Promise
---

# Как только транскрипция будет готова, я отправлю результат и сравню с tiny

Status: Pending

## Relationships
