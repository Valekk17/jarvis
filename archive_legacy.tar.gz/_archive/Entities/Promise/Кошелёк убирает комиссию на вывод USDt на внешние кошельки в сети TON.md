---
aliases:
- "\u041A\u043E\u0448\u0435\u043B\u0451\u043A \u0443\u0431\u0438\u0440\u0430\u0435\
  \u0442 \u043A\u043E\u043C\u0438\u0441\u0441\u0438\u044E \u043D\u0430 \u0432\u044B\
  \u0432\u043E\u0434 USDt \u043D\u0430 \u0432\u043D\u0435\u0448\u043D\u0438\u0435\
  \ \u043A\u043E\u0448\u0435\u043B\u044C\u043A\u0438 \u0432 \u0441\u0435\u0442\u0438\
  \ TON"
id: e6156db4-6e6f-4876-a94d-78977e456e49
tags:
- Promise
type: Promise
---

# Кошелёк убирает комиссию на вывод USDt на внешние кошельки в сети TON

Status: Active

## Relationships
