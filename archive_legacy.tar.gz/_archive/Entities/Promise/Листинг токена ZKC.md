---
aliases:
- "\u041B\u0438\u0441\u0442\u0438\u043D\u0433 \u0442\u043E\u043A\u0435\u043D\u0430\
  \ ZKC"
id: 61860728-d688-4b06-ac28-21ad834b44e1
tags:
- Promise
type: Promise
---

# Листинг токена ZKC

Status: Pending

## Relationships
