---
aliases:
- "\u041E\u0431\u043D\u043E\u0432\u0438\u043B \u043B\u043E\u0433\u0438\u043A\u0443\
  \ \u0438\u043C\u043F\u043E\u0440\u0442\u0430 (for Telegram)"
id: 712cd897-b7e4-4dd0-93a1-82349c73009a
tags:
- Promise
type: Promise
---

# Обновил логику импорта (for Telegram)

Status: Fulfilled

## Relationships
