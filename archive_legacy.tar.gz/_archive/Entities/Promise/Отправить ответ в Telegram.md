---
aliases:
- "\u041E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u043E\u0442\u0432\u0435\
  \u0442 \u0432 Telegram"
id: 7947b0df-cfda-4f21-8ab5-d7b657f32008
tags:
- Promise
type: Promise
---

# Отправить ответ в Telegram

Status: Ongoing

## Relationships
