---
aliases:
- "\u041E\u0442\u043F\u0440\u0430\u0432\u043B\u044F\u0442\u044C $HMSTR \u043A\u043E\
  \u043D\u0442\u0430\u043A\u0442\u0430\u043C \u0432 Telegram \u043C\u0433\u043D\u043E\
  \u0432\u0435\u043D\u043D\u043E \u0438 \u0431\u0435\u0437 \u043A\u043E\u043C\u0438\
  \u0441\u0441\u0438\u0438"
id: a611c5ca-cf1e-4540-aed3-a294b5bd718f
tags:
- Promise
type: Promise
---

# Отправлять $HMSTR контактам в Telegram мгновенно и без комиссии

Status: Fulfilled

## Relationships
