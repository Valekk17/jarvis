---
aliases:
- "\u041E\u0442\u043F\u0440\u0430\u0432\u043B\u044F\u0442\u044C \u0442\u043E\u043A\
  \u0435\u043D\u044B MAJOR \u0434\u0440\u0443\u0437\u044C\u044F\u043C \u0432 Telegram\
  \ \u0431\u0435\u0437 \u043A\u043E\u043C\u0438\u0441\u0441\u0438\u0438"
id: b3ab82b5-7922-4d1d-a2e8-e0bcb6670e3d
tags:
- Promise
type: Promise
---

# Отправлять токены MAJOR друзьям в Telegram без комиссии

Status: Fulfilled

## Relationships
