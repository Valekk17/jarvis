---
aliases:
- "\u041F\u0435\u0440\u0435\u0437\u0430\u043F\u0443\u0441\u0442\u0438\u043B \u043F\
  \u0440\u043E\u0446\u0435\u0441\u0441 \u0438\u043C\u043F\u043E\u0440\u0442\u0430\
  \ \u0438\u0441\u0442\u043E\u0440\u0438\u0438 Telegram (Phase 2)."
id: 445ed8ed-8767-4019-8d71-19e205a280f2
tags:
- Promise
type: Promise
---

# Перезапустил процесс импорта истории Telegram (Phase 2).

Status: Fulfilled

## Relationships
