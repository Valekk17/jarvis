---
aliases:
- "\u041F\u043E\u0436\u0430\u043B\u0443\u0439\u0441\u0442\u0430, \u043F\u0440\u0438\
  \u0433\u043E\u0442\u043E\u0432\u044C\u0442\u0435\u0441\u044C \u043F\u043E\u043B\u0443\
  \u0447\u0438\u0442\u044C \u043A\u043E\u0434 \u0435\u0449\u0435 \u0440\u0430\u0437\
  \ (Telegram authentication)"
id: 8a515e31-a728-4a25-aaf5-83933994c65d
tags:
- Promise
type: Promise
---

# Пожалуйста, приготовьтесь получить код еще раз (Telegram authentication)

Status: Pending

## Relationships
