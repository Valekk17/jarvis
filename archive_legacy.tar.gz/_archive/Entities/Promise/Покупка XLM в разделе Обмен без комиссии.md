---
aliases:
- "\u041F\u043E\u043A\u0443\u043F\u043A\u0430 XLM \u0432 \u0440\u0430\u0437\u0434\u0435\
  \u043B\u0435 \u041E\u0431\u043C\u0435\u043D \u0431\u0435\u0437 \u043A\u043E\u043C\
  \u0438\u0441\u0441\u0438\u0438"
id: 7520ba97-b792-4ca4-883a-433236be731a
tags:
- Promise
type: Promise
---

# Покупка XLM в разделе Обмен без комиссии

Status: Active

## Relationships
