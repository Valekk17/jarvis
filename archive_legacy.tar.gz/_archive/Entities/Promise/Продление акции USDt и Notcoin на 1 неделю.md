---
aliases:
- "\u041F\u0440\u043E\u0434\u043B\u0435\u043D\u0438\u0435 \u0430\u043A\u0446\u0438\
  \u0438 USDt \u0438 Notcoin \u043D\u0430 1 \u043D\u0435\u0434\u0435\u043B\u044E"
id: c5c306f5-f902-4c47-906d-9e2fa27b9a8e
tags:
- Promise
type: Promise
---

# Продление акции USDt и Notcoin на 1 неделю

Status: Fulfilled

## Relationships
