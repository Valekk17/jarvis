---
aliases:
- "\u0421\u0438\u0441\u0442\u0435\u043C\u0430 \u043D\u0430\u0445\u043E\u0434\u0438\
  \u0442 \u0443\u0437\u0435\u043B Decision \u0432 \u0433\u0440\u0430\u0444\u0435:\
  \ '\u041F\u0435\u0440\u0435\u0445\u043E\u0434 \u043D\u0430 Postgres'"
id: b3d896fa-bbf9-479e-b492-adb33b3d5e77
tags:
- Promise
type: Promise
---

# Система находит узел Decision в графе: 'Переход на Postgres'

Status: Pending

## Relationships
