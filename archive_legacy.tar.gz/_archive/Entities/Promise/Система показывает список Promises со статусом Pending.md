---
aliases:
- "\u0421\u0438\u0441\u0442\u0435\u043C\u0430 \u043F\u043E\u043A\u0430\u0437\u044B\
  \u0432\u0430\u0435\u0442 \u0441\u043F\u0438\u0441\u043E\u043A Promises \u0441\u043E\
  \ \u0441\u0442\u0430\u0442\u0443\u0441\u043E\u043C Pending"
id: c5e03c13-d092-4061-b7c0-0b0ea08b43f3
tags:
- Promise
type: Promise
---

# Система показывает список Promises со статусом Pending

Status: Pending

## Relationships
