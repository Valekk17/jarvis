---
aliases:
- "\u0421\u0438\u0441\u0442\u0435\u043C\u0430 \u0441\u0430\u043C\u0430 \u0441\u043E\
  \u0437\u0434\u0430\u0435\u0442 \u0437\u0430\u043C\u0435\u0442\u043A\u0443 \u0432\
  \ Obsidian, \u0432\u044B\u0434\u0435\u043B\u044F\u0435\u0442 \u0442\u0435\u0433\u0438\
  \ \u0438 \u0441\u0432\u044F\u0437\u0438 (Idea, Project)"
id: c7abf3f8-6f86-40b7-8fb3-9af8b4112406
tags:
- Promise
type: Promise
---

# Система сама создает заметку в Obsidian, выделяет теги и связи (Idea, Project)

Status: Pending

## Relationships
