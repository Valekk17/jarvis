---
aliases:
- "\u0421\u0442\u0430\u0440\u0442 \u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0438\
  \ \u0432 \u0441\u0435\u0439\u043B\u0435 Falcon Finance"
id: c8f8140d-f361-401d-970a-c45b110b8470
tags:
- Promise
type: Promise
---

# Старт подписки в сейле Falcon Finance

Status: Pending

## Relationships
