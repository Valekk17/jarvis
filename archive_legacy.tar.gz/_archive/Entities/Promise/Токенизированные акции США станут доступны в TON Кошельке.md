---
aliases:
- "\u0422\u043E\u043A\u0435\u043D\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u043D\u043D\
  \u044B\u0435 \u0430\u043A\u0446\u0438\u0438 \u0421\u0428\u0410 \u0441\u0442\u0430\
  \u043D\u0443\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B \u0432 TON \u041A\
  \u043E\u0448\u0435\u043B\u044C\u043A\u0435"
id: 1c64a6de-d90d-4e53-9054-7e6be2c66f3c
tags:
- Promise
type: Promise
---

# Токенизированные акции США станут доступны в TON Кошельке

Status: Fulfilled

## Relationships
