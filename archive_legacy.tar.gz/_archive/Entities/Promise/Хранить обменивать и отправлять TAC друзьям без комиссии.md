---
aliases:
- "\u0425\u0440\u0430\u043D\u0438\u0442\u044C, \u043E\u0431\u043C\u0435\u043D\u0438\
  \u0432\u0430\u0442\u044C \u0438 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u044F\
  \u0442\u044C TAC \u0434\u0440\u0443\u0437\u044C\u044F\u043C \u0431\u0435\u0437 \u043A\
  \u043E\u043C\u0438\u0441\u0441\u0438\u0438"
id: 05b0f20e-2dc1-4fee-a89e-37ba657fc5cd
tags:
- Promise
type: Promise
---

# Хранить, обменивать и отправлять TAC друзьям без комиссии

Status: Fulfilled

## Relationships
