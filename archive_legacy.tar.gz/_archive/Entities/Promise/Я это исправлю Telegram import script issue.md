---
aliases:
- "\u042F \u044D\u0442\u043E \u0438\u0441\u043F\u0440\u0430\u0432\u043B\u044E (Telegram\
  \ import script issue)"
id: 099ef5d2-0be5-4e53-b093-2a6afaedb7ad
tags:
- Promise
type: Promise
---

# Я это исправлю (Telegram import script issue)

Status: Pending

## Relationships
