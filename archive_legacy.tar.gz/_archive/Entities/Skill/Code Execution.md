---
aliases:
- Code Execution
id: c4226463-db84-409b-9a89-9c119169a363
tags:
- Skill
type: Skill
---

# Code Execution

Python, bash, Docker, PostgreSQL, file management

## Relationships
