---
aliases:
- Voice Processing
id: 20f3e784-4887-4b70-a6ff-3c405f241ce0
tags:
- Skill
type: Skill
---

# Voice Processing

Whisper transcription (base model), voice command recognition

## Relationships
