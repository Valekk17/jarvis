---
aliases:
- Whisper
id: b1abac03-d62e-41a4-905a-6c62fd5c378b
tags:
- Skill
type: Skill
---

# Whisper

Voice Transcription

## Relationships

### Incoming
- [[Jarvis]] -> **HAS_SKILL**
