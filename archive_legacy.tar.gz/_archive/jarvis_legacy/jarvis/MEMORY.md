# Long-Term Memory

## System
- JARVIS initialized: 2025-07-11
- Graph schema: ONTOLOGY.md v1
- Anti-noise filter: active

## Key Facts
- Owner is military serviceman in Serpukhov
- Wife: Arisha (priority contact)
- Primary project: building JARVIS bot with context graph

## Lessons Learned
- (auto-populated by JARVIS as patterns emerge)
