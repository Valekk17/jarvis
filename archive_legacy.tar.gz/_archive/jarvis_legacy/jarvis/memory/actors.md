# Actor Registry

## actor-andrey
- canonical_name: Andrey Kovalkov
- aliases: ['Андрей', 'брат', 'Ковальков', 'brother']
- role: family
- context: brother

## actor-arisha
- canonical_name: Arisha
- aliases: ['Ариша', 'жена', 'wife', 'Мой Мир']
- role: family
- context: wife, pregnant ~12.3 weeks, chat Мой Мир❤️, insurance issues, priority contact

## actor-evgeniya
- canonical_name: Evgeniya Kovalkova
- aliases: ['мама', 'Евгения', 'Ковалькова', 'mom']
- role: family
- context: mother

## actor-jarvis
- canonical_name: JARVIS
- aliases: ['Джарвис', 'jarvis', 'бот', 'bot', 'assistant']
- role: system
- context: Personal AI Operating System. Model: Claude Opus 4.6 + Gemini. Platform: OpenClaw.

## actor-leha-kosenko
- canonical_name: Alexey Kosenko
- aliases: ['Лёха', 'Леха', 'Leha', 'Косенко', 'Kosenko']
- role: friend
- context: friend from Moscow

## actor-owner
- canonical_name: Valekk_17
- aliases: ['я', 'мне', 'мой', 'valekk', 'valekk_17']
- role: owner
- context: military serviceman, Serpukhov, building JARVIS bot, income ~3000 RUB mentioned

