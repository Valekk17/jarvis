# Decisions

## dec-claude
- content: Switch to Claude Opus 4.6 as primary model
- date: 2026-02-14
- source_quote: "модель Claude Opus 4.6"
- confidence: 0.9

## dec-cyb-os
- content: Adopt cybOS architecture for JARVIS
- date: 2026-02-14
- source_quote: "cybOS и Граф Контекста"
- confidence: 0.9

## dec-english
- content: All internal JARVIS files in English (saves ~30% tokens)
- date: 2026-02-14
- source_quote: "сделай все файлы на английском"
- confidence: 0.9

## dec-gemini-embed
- content: Use Gemini Embeddings (gemini-embedding-001)
- date: 2026-02-14
- source_quote: "Adopted Google Gemini Embeddings"
- confidence: 0.9

## decision-3c34b51f
- content: выйти в 18:30
- date: 2026-02-14
- source_quote: "Тогда нужно в 18.30 выходить"
- confidence: 0.9

## decision-d8b21531
- content: написать ассистенту
- date: 2026-02-14
- source_quote: "Ну вот я написала ассистенту"
- confidence: 0.9

## decision-e8d858e6
- content: написать в поддержку
- date: 2026-02-14
- source_quote: "Написала в поддержку"
- confidence: 0.9

## dec-markdown
- content: Context graph in markdown files + PostgreSQL
- date: 2026-02-14
- source_quote: "Build context graph using markdown files"
- confidence: 0.9

## dec-postgres
- content: Use PostgreSQL in Docker for graph storage
- date: 2026-02-14
- source_quote: "Агент решил что PostgreSQL эффективнее"
- confidence: 0.9

