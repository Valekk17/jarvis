# Plans

## plan-02c7099e
- content: составить табличку
- status: active
- source_quote: "Надо вообще составить наверное табличку"
- target_date: null
- confidence: 0.9

## plan-08d823bb
- content: fill something out
- status: active
- source_quote: "Заполню"
- target_date: null
- confidence: 0.8

## plan-30d36203
- content: покидать всем коллаж фотокарточки
- status: active
- source_quote: "Надо им всем коллаж фотокарточки покидать наверное"
- target_date: null
- confidence: 0.9

## plan-4c5f9bb2
- content: избавиться от мата
- status: active
- source_quote: "надо кстати избавляться по-хорошему"
- target_date: null
- confidence: 0.8

## plan-5d2d83fe
- content: go home
- status: active
- source_quote: "Завтра домой"
- target_date: null
- confidence: 0.9

## plan-75b93584
- content: не сидеть в тиктоке
- status: active
- source_quote: "Главное знаешь, вот самим тоже не сидеть в тиктоке 😃"
- target_date: null
- confidence: 0.7

## plan-9d84780e
- content: приехать к сыну
- status: active
- source_quote: "сына скоро приеду"
- target_date: null
- confidence: 0.8

## plan-a8f2d8ac
- content: повести в столовку
- status: active
- source_quote: "Я же в столовку поведу"
- target_date: null
- confidence: 0.9

## plan-appeal
- content: Submit appeal
- status: active
- source_quote: "подать апелляцию"
- target_date: null
- confidence: 0.9

## plan-auto-collect
- content: Cron-based auto-collector: Telegram → Gemini extraction every 2h
- status: active
- source_quote: "Auto-collector cron для Telegram ingestion"
- target_date: null
- confidence: 0.9

## plan-b6c7c6e8
- content: стараться (в воспитании ребенка)
- status: active
- source_quote: "Но блин, реально нам нужно будет стараться"
- target_date: null
- confidence: 0.9

## plan-baby
- content: Baby due before September 2026
- status: active
- source_quote: "ребенок родится до сентября"
- target_date: 2026-09-01
- confidence: 0.9

## plan-bfe445aa
- content: пойти вечером за тестом в монеточку
- status: active
- source_quote: "Так, вечером за тестом в монеточку"
- target_date: null
- confidence: 0.9

## plan-collage
- content: Make photo collage and send to everyone
- status: active
- source_quote: "сделать коллаж из фотографий"
- target_date: null
- confidence: 0.9

## plan-f3894883
- content: читать всякие умные книжки (ребенку)
- status: active
- source_quote: "Будете всякие умные книжки читать"
- target_date: null
- confidence: 0.8

## plan-f507a49b
- content: сделать дела
- status: active
- source_quote: "Надо сделать дела то"
- target_date: null
- confidence: 0.9

## plan-gemini-extract
- content: Use Gemini 2.5 Pro (free) for all entity extraction, not Claude
- status: active
- source_quote: "Gemini free tier для extraction, Claude только для ответов"
- target_date: null
- confidence: 0.9

## plan-mcp
- content: Build MCP Server for automatic graph queries before responses
- status: active
- source_quote: "обернуть граф как MCP Server"
- target_date: null
- confidence: 0.9

## plan-multi-chat
- content: Process all key Telegram chats (not just Arisha)
- status: active
- source_quote: "Обработка других чатов (пока только Ариша)"
- target_date: null
- confidence: 0.9

## plan-obsidian
- content: Integrate Obsidian vault for voice → transcription → notes
- status: active
- source_quote: "Obsidian — Голос → транскрипция → заметка"
- target_date: null
- confidence: 0.9

## plan-postgres
- content: PostgreSQL in Docker for graph + visualization
- status: active
- source_quote: "PostgreSQL граф — хранение сущностей"
- target_date: null
- confidence: 0.9

## plan-semantic
- content: Implement semantic search over dialogs
- status: active
- source_quote: "Семантический поиск по диалогам"
- target_date: null
- confidence: 0.9

## plan-support
- content: Write to insurance support
- status: active
- source_quote: "написать в поддержку"
- target_date: null
- confidence: 0.9

## plan-voice-svc
- content: voice_watcher.py as systemd service (auto-restart)
- status: active
- source_quote: "voice_watcher как systemd service"
- target_date: null
- confidence: 0.9

