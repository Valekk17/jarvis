# Promises

## promise-7401d6a3
- from: actor-owner
- to: actor-arisha
- content: прийти
- deadline: null
- status: expired
- source_quote: "Приду❤️"
- source_date: 2026-02-14
- confidence: 0.9

## promise-cb58ea89
- from: actor-owner
- to: actor-arisha
- content: не прийти на ужин
- deadline: null
- status: expired
- source_quote: "Не приду на ужин"
- source_date: 2026-02-14
- confidence: 0.9

## promise-42b1f8dc
- from: actor-arisha
- to: actor-owner
- content: показывать и рассказывать детям как сильно тебя люблю и как ты меня любишь
- deadline: null
- status: pending
- source_quote: "Вообще всегда буду показывать и рассказывать детям как сильно тебя люблю и как ты меня любишь"
- source_date: 2026-02-14
- confidence: 0.9

## promise-6e001623
- from: actor-owner
- to: actor-arisha
- content: скачать и скинуть фотки
- deadline: null
- status: pending
- source_quote: "Скачай и скинь"
- source_date: 2026-02-14
- confidence: 0.9

## promise-a9a15ce4
- from: actor-owner
- to: actor-arisha
- content: отправить напоминание Комбату
- deadline: null
- status: pending
- source_quote: "Комбату отправь напоминание"
- source_date: 2026-02-14
- confidence: 0.9

## promise-deo
- from: actor-owner
- to: actor-arisha
- content: order deodorants
- deadline: null
- status: pending
- source_quote: "заказать дезодоранты"
- source_date: 2026-02-14
- confidence: 0.9

## promise-ins
- from: actor-arisha
- to: actor-owner
- content: insurance will be free
- deadline: null
- status: pending
- source_quote: "страховка будет бесплатной"
- source_date: 2026-02-14
- confidence: 0.9

## promise-leha
- from: actor-leha-kosenko
- to: actor-owner
- content: send report
- deadline: null
- status: pending
- source_quote: "обещал скинуть отчет до пятницы"
- source_date: 2026-02-14
- confidence: 0.9

